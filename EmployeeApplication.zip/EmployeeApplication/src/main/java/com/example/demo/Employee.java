package com.example.demo;

import jakarta.persistence.*;

@Entity
@Table(name="employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int age;
    private String designation;
    private int salary;
    

    public Employee() {}

   
    

    // getters & setters
    public Long getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getDesignation() { return designation; }
    public int getSalary() {
    	return salary;
    }
    

    
    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setDesignation(String designation) { this.designation = designation; }
    public void setSalary(int salary) {
    	this.salary=salary;
    }
  
}