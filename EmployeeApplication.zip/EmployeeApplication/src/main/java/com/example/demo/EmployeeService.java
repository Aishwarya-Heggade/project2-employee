package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    public Employee createEmployee(Employee e) {
        if (e.getDesignation().equalsIgnoreCase("programmer"))
            e.setSalary(20000);
        else if (e.getDesignation().equalsIgnoreCase("manager"))
            e.setSalary(25000);
        else
            e.setSalary(15000);

        return repo.save(e);
    }

    public List<Employee> getAll() {
        return repo.findAll();
    }

    public String raiseSalary(String name, int percent) {
        Employee emp = repo.findByNameIgnoreCase(name).orElse(null);
        if (emp == null) return "Employee not found";

        int newSalary = emp.getSalary() + (emp.getSalary() * percent / 100);
        emp.setSalary(newSalary);
        repo.save(emp);

        return "Updated Salary = " + newSalary;
    }
}