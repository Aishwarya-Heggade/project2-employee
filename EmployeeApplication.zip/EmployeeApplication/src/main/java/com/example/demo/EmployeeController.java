package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // ================= CREATE EMPLOYEE =================
    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {

        String desig = employee.getDesignation().toLowerCase();
        int salary;

        switch (desig) {
            case "programmer":
                salary = 20000;
                break;
            case "manager":
                salary = 25000;
                break;
            case "tester":
                salary = 15000;
                break;
            default:
                throw new RuntimeException("Invalid designation");
        }

        employee.setSalary(salary);

        return employeeRepository.save(employee);
    }

    // ================= GET ALL EMPLOYEES =================
    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // ================= RAISE SALARY =================
    @PutMapping("/raise/{id}/{percent}")
    public Employee raiseSalary(@PathVariable Long id,
                                @PathVariable int percent) {

        if (percent < 1 || percent > 10) {
            throw new RuntimeException("Raise % must be between 1 and 10");
        }

        Employee emp = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        int updatedSalary = emp.getSalary()
                + (emp.getSalary() * percent / 100);

        emp.setSalary(updatedSalary);

        return employeeRepository.save(emp);
    }
 // ================= DELETE EMPLOYEE =================
    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Long id) {

        if (!employeeRepository.existsById(id)) {
            return "Employee with ID " + id + " not found";
        }

        employeeRepository.deleteById(id);
        return "Employee with ID " + id + " deleted successfully";
    }

}
